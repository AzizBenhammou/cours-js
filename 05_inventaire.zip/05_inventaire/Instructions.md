# Inventaire d'un magasin

- Il faut dans un premier temps afficher tous les produits du magasin sous forme de liste au clic d'un bouton.
Les produits seront stockés dans un tableau d'objets dans votre script. Chaque produit à un nom, un prix et une catégorie.

- Ensuite il va falloir créer un sytème de filtrage pour n'afficher que les produits d'une catégorie voulue en cliquant sur son bouton attitré. Ces boutons s'ajouteront en plus du premier bouton que nous avions.