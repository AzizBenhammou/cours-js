# Citation

Le HTML et le CSS sont fournit pour cet exercice, il va falloir cette fois récupérer les citations et auteurs entrés par l'utilisateur dans les champs de texte correspondants.

Une fois ces data récupérées, créez une div pour pouvoir afficher les afficher sur la page.
Attention ces éléments sont créés si on a des valeurs dans les champs.