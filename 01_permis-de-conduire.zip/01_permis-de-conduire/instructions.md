# Validation permis de conduire

- Demander à l'utilisateur son âge et s'il a le permis.
Selon ses réponses,  afficher sur la page le message approprié.
Soit il doit a plus de 18 et a le permis, soit il a plus de 18 ans mais n'a pas le permis soit il est trop jeune.