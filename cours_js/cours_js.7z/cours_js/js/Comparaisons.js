let number = 123;
let number2 = "123";

// vérifie si les variables sont égales en valeurs
console.log(number == number2); // renvoie true

// vérifie si les variables sont égales en valeurs et en type
console.log(number === number2); // renvoie false

// vérifie si les variables sont différentes en valeurs
console.log(number != number2); // renvoie false

// vérifie si les variables sont différentes en valeurs et en type
//  variable strictement différente à
console.log(number !== number2); // renvoie false
