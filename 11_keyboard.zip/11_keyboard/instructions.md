# Keyboard

Créer un carré de taille et couleur de votre choix.

- À l'aide des flèches sur les touches de votre clavier, il va falloir réussir à déplacer ce carré sur la page.
Vous devrez donc faire appel au bon évènement pour se faire et utiliser la condition switch également.