# Que la lumière soit

* L'objectif de l'exercice est de permettre de changer l'image de l'ampoule par une
    ampoule allumée ou éteinte, au fur et à mesure qu'on clique sur le bouton à côté.
* Le bouton doit également changer de texte avec l'action qui va se produire si on clique dessus.

* Faites également en sorte que le fond de la page change en même temps que l'image. Quand l'ampoule est allumée, le fond est sombre.
 