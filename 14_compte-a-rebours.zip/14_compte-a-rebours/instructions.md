# Deadline

Ici nous procéderons à une simulation d'un compte à rebours avant d'accéder à une page d'un site.
Vous aurez donc une page principale qui sera index.html et une autre qui servira pour la redirection.

Dans votre script il faudra utiliser l'objet js Date pour mettre en place une date de fin pour l'arrêt du compte à rebours.
Cet objet servira également pour récupérer la date et l'heure actuelle. En effet nous ferons le décompte entre l'instant T et la date de fin.

Réfléchissez au calcul qu'il faudra faire pour pouvoir afficher les jours, heures, minutes et secondes restantes avant de gérer une redirection.