# Valider un formulaire

Nous avons déjà vu comment récupérer des valeurs d'un champs de texte, comment ne pas laisser un champs vide mais comment réellement vérifier de manière concrète un formulaire à la soumission ?

Ici il va falloir faire en sorte de créer un formulaire dans le html afin de permettre à l'utilisateur de faire ses informations (nom, âge et mot de passe).

Vous aurez également besoin de 2 div pour gérer les messages d'erreurs. Les messages d'erreurs seront affichés en rouge, le message de formulaire envoyé avec succès sera quant à lui en vert.

- Le nom ne doit être en aucun cas laissé vide
- Il faut limiter l'âge de l'utilisateur (libre choix des limite)
- Le format du mot de passe devra être vérifié également.