# localStorage

* Méthodes clés :

- setItem(key, value) : Stocke une paire clé-valeur dans le localStorage.
- getItem(key) : Récupère la valeur associée à la clé spécifiée.
- removeItem(key) : Supprime la clé spécifiée et sa valeur associée.
- clear() : Supprime toutes les données du localStorage.