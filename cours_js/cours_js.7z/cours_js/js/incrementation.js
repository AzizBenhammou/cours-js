// -- Incrémentation
let nb1 = 1;
nb1 = nb1 + 1;
// affichage => nb1 = 2
console.log(`Incrémentation avec opérateur: ${nb1}`);

// Ecriture simplifiée
nb1++;
// affichage => nb1 = 3
console.log(`Incrémentation simplifiée: ${nb1}`);

// Ecriture simplifiée
++nb1;

// affichage => nb1 = 4
console.log(nb1);

// -- décrémentation
nb1 = nb1 - 1;
console.log(`Décrémentation avec opérateur: ${nb1}`);

// écriture simplifiée
nb1--;
console.log(`Décrémentation simplifiée: ${nb1}`);
// écriture simplifiée
--nb1;
console.log(`Décrémentation simplifiée: ${nb1}`);
